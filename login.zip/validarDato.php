<html>
    <head>
        <title>Validacion</title>
    </head>

    <body>
        <form name="ValidandoDatos">
            <label>
                <?php 
                if ($_POST["Usuario"] == "jperez" and $_POST["Contra"] == "9999"):
                        echo "Bienvenido al sistema, Juan Perez";
                    else:
                        echo "Usuario y/o contraseña incorrectos.Intentar nuevamente.";
                    endif;
                    ?>
                </label>
        </form> 
    </body>
</html>